/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package actividad.n.pkg2;

import java.util.Scanner;

/**
 *
 * @author Ambiente 209-3
 */
public class ActividadN2 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[][] matriz1 = new int[3][3];
        int[][] matriz2 = new int[3][3];
        int[][] suma = new int[3][3];
        Scanner sc = new Scanner(System.in);
        
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                 System.out.println("Ingrese el valor para la matriz 1: " + (i + 1) + "," + (j + 1));
                matriz1[i][j] = sc.nextInt();
            }
        }
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                 System.out.println("Ingrese el valor para la matriz 2 " + (i + 1) + "," + (j + 1));
                matriz2[i][j] = sc.nextInt();
            }
        }
        //SUMA DE LAS MATRIZES
        for (int i = 0; i < 3; i++) {
            System.out.print("|");
            for (int j = 0; j < 3; j++) {
                suma[i][j] = matriz1[i][j] + matriz2[i][j];
                 System.out.println("El valor de "+matriz1[i][j] +"+"+ matriz2[i][j]+" la suma de la matriz de " + (i + 1) + "," + (j + 1));
                 System.out.println("es: "+suma[i][j]);
            }
        }
    }
}
