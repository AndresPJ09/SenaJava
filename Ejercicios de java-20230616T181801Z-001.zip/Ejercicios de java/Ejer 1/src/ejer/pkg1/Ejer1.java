/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejer.pkg1;

import java.util.Scanner;

/**
 *
 * @author Jackeline
 */
public class Ejer1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Hacer un algoritmo que almacene números en una matriz de 2 * 3. 
        //Imprimir la suma de los números almacenados en la matriz.
        Scanner sc = new Scanner(System.in);
        int[][] matriz = new int[2][3];
        int sumatotal = 0;
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.println("Ingrese el valor para la matriz: " + (i + 1) + "," + (j + 1));
                matriz[i][j] = sc.nextInt();
                sumatotal += matriz[i][j];
            }
        }
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.println("El valor de la suma de la matriz de " + (i + 1) + "," + (j + 1) + " es: " + matriz[i][j]);
            }
        }

        System.out.println("La suma de los números almacenados en la matriz es: " + sumatotal);
    }
}
