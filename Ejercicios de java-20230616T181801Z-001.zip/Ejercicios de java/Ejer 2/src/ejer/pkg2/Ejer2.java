/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejer.pkg2;

import java.util.Scanner;

/**
 *
 * @author Jackeline
 */
public class Ejer2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Hacer un algoritmo que llene una matriz de 5 * 5 y determine la posición
        //Renglones y columnas
        //del número mayor almacenado en la matriz. Los números son diferentes.
        Scanner sc = new Scanner(System.in);
        int[][] matriz = new int[5][5];
        int maximo = Integer.MIN_VALUE;
        int Fila = -1;
        int Columna = -1;

        // Llenar la matriz con números diferentes
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print("Ingrese el valor para la posición (" + (i + 1) + "," + (j + 1) + "): ");
                int numero = sc.nextInt();
                matriz[i][j] = numero;
                if (numero > maximo) {
                    maximo = numero;
                    Fila = i;
                    Columna = j;
                }
            }
        }

        // Mostrar la matriz
        for (int i = 0; i < 5; i++) {
            System.out.print("| ");
            for (int j = 0; j < 5; j++) {
                System.out.print(matriz[i][j] + " | ");
            }
            System.out.println();
        }

        // Mostrar la posición del número mayor
        System.out.println("El número mayor es: " + maximo);
        System.out.println("Se encuentra en la posición " + (Fila + 1) + "," + (Columna + 1) + "");
    }
}