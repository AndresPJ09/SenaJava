/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejer3;
import java.util.Scanner;
/**
 *
 * @author Jackeline
 */
public class Ejer3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Hacer un algoritmo que llene una matriz de 3 * 3. Calcular la suma de cada renglón y 
        //almacenarla en un vector, la suma de cada columna y almacenarla en otro vector.
        int[][] matriz = new int[3][3];
        int[] sumasFilas = new int[3]; // Vector para almacenar las sumas de las filas
        int[] sumasColumnas = new int[3]; // Vector para almacenar las sumas de las columnas
        Scanner scanner = new Scanner(System.in);

        // Llenar la matriz con los valores ingresados por el usuario
        System.out.println("Ingrese los valores de la matriz:");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print("Ingrese el valor para la posición (" +(i+1)+",columna "+(j+1));
                matriz[i][j] = scanner.nextInt();
            }
        }

        // Calcular la suma de cada fila y almacenarla en el vector sumasFilas
        for (int i = 0; i < 3; i++) {
            int sumaFila = 0;
            for (int j = 0; j < 3; j++) {
                sumaFila += matriz[i][j];
            }
            sumasFilas[i] = sumaFila;
        }

        // Calcular la suma de cada columna y almacenarla en el vector sumasColumnas
        for (int j = 0; j < 3; j++) {
            int sumaColumna = 0;
            for (int i = 0; i < 3; i++) {
                sumaColumna += matriz[i][j];
            }
            sumasColumnas[j] = sumaColumna;
        }

        // Imprimir la matriz y las sumas de las filas y columnas
        System.out.println("Matriz:");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println();
        }

        System.out.println("Sumas de las filas:");
        for (int i = 0; i < 3; i++) {
            System.out.println("Fila " + (i + 1) + ": " + sumasFilas[i]);
        }

        System.out.println("Sumas de las columnas:");
        for (int j = 0; j < 3; j++) {
            System.out.println("Columna " + (j + 1) + ": " + sumasColumnas[j]);
        }
    }
}
    
    

